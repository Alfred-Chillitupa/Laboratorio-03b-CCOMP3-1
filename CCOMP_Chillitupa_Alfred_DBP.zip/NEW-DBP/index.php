<!DOCTYPE html>
    
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>T Companies</title>

        <link rel="icon" type="image/png" href="img/icon.png">

        <!-- CSS -->
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        
    </head>
    
    <body>

        <!-- LOADER -->

        <div id="loader">
            <img src="img/loader.gif" alt="" width="30%"/>
        </div>  

        <!-- NAVBAR -->

        <nav class="navbar navbar-expand-lg navbar-light fixed-top" style="background-color: #e3f2fd;" >
            
            <a class="navbar-brand" href="index.php">
                <img src="img/T.png" width="30" height="30" class="d-inline-block align-top" alt=""> Companies
            </a>
            
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav">
                    <li class="nav-item active">
                        <a class="nav-link" href="https://about.google/intl/es-419/" target="_blank">Google <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="https://www.microsoft.com/es-es/about" target="_blank">Microsoft</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="https://www.apple.com/" target="_blank">Apple</a>
                    </li>
                </ul>
            </div>

            <button class="btn btn-outline-success my-2 my-sm-0" data-toggle="modal" data-target="#navbarModal">Download Full XML</button>
            
        </nav>

        <!-- NAVBAR MODAL -->

        <div class="modal fade" id="navbarModal" tabindex="-1" aria-labelledby="navbarModal" aria-hidden="true">
            <div class="modal-dialog" >
                <div class="modal-content main-section">
                    
                    <div class="modal-header">
                        <div class="col-12 user-image text-center" >
                        <img src="img/UCSP.png" >
                        </div>
                    </div>
                    
                    <div class="modal-body">
                        <h5>TASK DBP XML VIEWER</h5>
                            <p>This viewer is the result of the teamwork of a group of Computer Science students for the Platform-Based Development course. HTML, CSS, JS, BOOSTRAP, XML, and PHP was used. We hope you like it !!</p>
                            <hr>
                        <h5>TeamWork</h5>
                            <p>
                            Alfred Addison Chillitupa Quispihuanca
                            <a href="#" class="tooltip-test" title="Tooltip" target="_blank">Contact Me</a></p>
                            <p>
                            Rayver Aimar Muñoz Curi
                            <a href="#" class="tooltip-test" title="Tooltip" target="_blank">Contact Me</a></p>
                            <p>
                            Emmanuel Sammir Galdos Rodriguez
                            <a href="#" class="tooltip-test" title="Tooltip" target="_blank">Contact Me</a></p>
                                  
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <a href="xml/fullCompanies.xml" role="button" class="btn btn-warning popover-test" target="_blank">Download</a>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    
        <!-- SLIDER -->
	
        <div id="carouselExampleCaptions" class="carousel slide carousel-fade" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
                <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
            </ol>
            
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="img/1.jpg" class="d-block w-100" alt="google">
                    <div class="carousel-caption d-none d-md-block">
                        <h5>Google</h5>
                        <p>Our mission is to organize the world's information so that everyone can access and use it.</p>
                        <button type="button" class="btn btn-light" onclick="location.href='google.php'">Let's go!</button>
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="img/2.jpg" class="d-block w-100" alt="google">
                    <div class="carousel-caption d-none d-md-block">
                        <h5>Microsoft</h5>
                        <p>Our mission is to empower every person and every organization on the planet to achieve more.</p>
                        <button type="button" class="btn btn-danger" onclick="location.href='microsoft.php'">Let's go!</button>
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="img/3.jpg" class="d-block w-100" alt="google">
                    <div class="carousel-caption d-none d-md-block">
                        <h5>Apple</h5>
                        <p>Apple's mission statement is to provide the best user experience to its customers through its innovation.</p>
                        <button type="button" class="btn btn-dark" onclick="location.href='apple.php'">>Let's go!</button>
                    </div>
                </div>
            </div>
            
            <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    
        
        <script src="js/jquery-3.5.1.slim.min.js"></script>
        <script src="js/popper.min.js"></script>
        <script src="js/bootstrap.min.js"></script>

    </body>
    
    <!-- SCRIPTS -->
    
    <script type="text/javascript">
        var loader = document.getElementById("loader");
        
        setTimeout(function(){  
        loader.style.height = "100px";
        loader.style.width = "100px";
        loader.style.borderRadius = "50%";
        loader.style.visibility = "hidden";  }, 4000);

    </script>
    
</html>