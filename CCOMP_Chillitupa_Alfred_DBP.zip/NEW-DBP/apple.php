<?php
    if(isset($_POST['insert'])){
        
        $xml = new DomDocument("1.0","utf-8");
        $xml->load('xml/apple.xml');

        $name = $_POST['name'];
        $developer = $_POST['developer'];
        $date = $_POST['date'];
        $pricing = $_POST['pricing'];
        $category= $_POST['category'];

        $rootTag = $xml->getElementsByTagName("apple")->item(0);

        $productTag = $xml->createElement("product");
            $nameTag = $xml->createElement("name", $name );
            $developerTag = $xml->createElement("developer", $developer);
            $dateTag = $xml->createElement("date", $date);
            $pricingTag = $xml->createElement("pricing", $pricing);
            $categoryTag =$xml->createElement("category", $category);
        
            $productTag->appendChild($nameTag);
            $productTag->appendChild($developerTag);
            $productTag->appendChild($dateTag);
            $productTag->appendChild($pricingTag);
            $productTag->appendChild($categoryTag);

        $rootTag->appendChild($productTag);

        $xml->save('xml/apple.xml');
    }

    if(isset($_POST['deleteMe'])){
        $xml = new DomDocument("1.0","UTF-8");
        $xml->load('xml/apple.xml');

        $name = $_POST['name'];
        
        $xpath = new DOMXPATH($xml);

        foreach($xpath->query("/apple/product[name='$name']") as $node){
            $node->parentNode->removeChild($node);
        }

        $xml->formatoutput = true;
        $xml->save('xml/apple.xml');
    }

?>

<!DOCTYPE html>
    
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Apple</title>

        <link rel="icon" type="image/png" href="img/A.png">

         <!-- CSS -->
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        
    </head>
    
    <body>

        <!-- LOADER -->

        <div id="loader" style="background-color: white;">
            <img src="img/loaderA.gif" alt="" width="30%"/>
        </div>  

        <!-- NAVBAR -->

        <nav class="navbar navbar-expand-lg navbar-light " style="background-color: #AEE1CD;" >
            
            <a class="navbar-brand" href="index.php">
                <img src="img/google.png" width="80" height="30" class="d-inline-block align-top" alt=""> 
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02"  aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
                <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="google.php" target="_blank">Google</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="microsoft.php" target="_blank">Microsoft</a>
                    </li>
                </ul>
            
            
            <button class="btn btn-light" data-toggle="modal" data-target="#insertModal">Insert Data</button>
            <button class="btn btn-secondary" data-toggle="modal" data-target="#deleteModal" style="margin:6px;">Delete Data</button>
            <button class="btn btn-warning" data-toggle="modal" data-target="#navbarModal">Download Apple XML</button>
            
            </div>
        </nav>

        <!-- NAVBAR MODAL -->

        <div class="modal fade" id="navbarModal" tabindex="-1" aria-labelledby="navbarModal" aria-hidden="true">
            <div class="modal-dialog" >
                <div class="modal-content main-section">
                    
                    <div class="modal-header">
                        <div class="col-12 user-image text-center" >
                        <img src="img/UCSP.png" >
                        </div>
                    </div>
                    
                    <div class="modal-body">
                        <h5>TASK DBP XML VIEWER</h5>
                            <p>This viewer is the result of the teamwork of a group of Computer Science students for the Platform-Based Development course. HTML, CSS, JS, BOOSTRAP, XML, and PHP was used. We hope you like it !!</p>
                            <hr>
                        <h5>TeamWork</h5>
                            <p>
                            Alfred Addison Chillitupa Quispihuanca
                            <a href="#" class="tooltip-test" title="Tooltip" target="_blank">Contact Me</a></p>
                            <p>
                            Rayver Aimar Muñoz Curi
                            <a href="#" class="tooltip-test" title="Tooltip" target="_blank">Contact Me</a></p>
                            <p>
                            Emmanuel Sammir Galdos Rodriguez
                            <a href="#" class="tooltip-test" title="Tooltip" target="_blank">Contact Me</a></p>
                                  
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <a href="xml/google.xml" role="button" class="btn btn-warning popover-test" target="_blank">Download</a>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>

        <!-- INSERT MODAL -->

        <!-- Modal -->
        <div class="modal fade" id="insertModal" tabindex="-1" aria-labelledby="insertModal" aria-hidden="true">
            <div class="modal-dialog" >
                <div class="modal-content main-section">
                    <div class="modal-header">
                        <div class="col-12 user-image text-center" >
                        <img src="img/A.png" >
                        </div>
                    </div>
                    <div class="modal-body">
                    
                    <form method="POST" action="apple.php">
                        <div class="row">
                        <div class="col">
                                <input type="text" class="form-control" id="name" placeholder="Category product" name="category">
                            </div>
                            </div>
                        </div>
                        <br>

                        <div class="row">
                            <div class="col">
                                <input type="text" class="form-control" id="name" placeholder="Nombre del producto" name="name">
                            </div>
                            <div class="col">
                                <input type="text" class="form-control" id="developer" placeholder="Developer" name="developer">
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col">
                                <input type="date" class="form-control" id="date" placeholder="Date" name="date">
                            </div>
                            <div class="col">
                                <input type="text" class="form-control" id="pricing" placeholder="Precio" name="pricing">
                            </div>
                        </div>
                        <br>
                        <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <input type="submit"  name="insert" value"Insert product" class="btn btn-primary">
                    </div>
                    </form>

                    </div>
                    
                </div>
            </div>
        </div>

        <!-- DELET MODAL -->
        <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModal" aria-hidden="true">
            <div class="modal-dialog" >
                <div class="modal-content main-section">
                    <div class="modal-header">
                        <div class="col-12 user-image text-center" >
                        <img src="img/A.png" >
                        </div>
                    </div>
                    <div class="modal-body">
                    
                    <form method="POST" action="apple.php">
                        <div class="row">
                            <div class="col">
                                <input type="text" class="form-control" id="name" placeholder="Nombre del producto" name="name">
                            </div>
                        </div>
                        
                        <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <input type="submit"  name="deleteMe" value"Delete product" class="btn btn-danger">
                    </div>
                    </form>

                    </div>
                    
                </div>
            </div>
        </div>

        

        <div class="text-center">
            <img src="img/bg3.jpg" class="rounded" alt="first" height="570" widht="770">
        </div><br><br>

        <?php
            $xmlC= new SimpleXMLElement('xml/apple.xml',0,TRUE);
        ?>

        <!-- INVENTOR CARD -->
        <div class="card mb-3" style="max-width: 1000px;border-color:#1F2020; margin-left:13%">
            <div class="row no-gutters">
                <div class="col-md-4">
                    <img src="img/steve.png" class="card-img" alt="">
                </div>
                <div class="col-md-8">
                    <div class="card-body">
                        <?php foreach($xmlC->info as $inf) :?>
                        <h5 class="card-title"><?php echo $inf->creador?></h5>
                            <p class="card-text">Lanzó Apple el año: <?php echo $inf->fechaC?> </p>
                            <p class="card-text">País de lanzamiento: <?php echo $inf->pais?> </p>
                            <p class="card-text">Escrito en los lenguajes: <?php echo $inf->pgrLan?> </p>
                            <p class="card-text">Trabajo junto con <?php echo $inf->teamW?> </p>
                            <p class="card-text">Descripción de Apple actualmente <?php echo $inf->description?> </p>
                            <p class="card-text">Lema de trabajo <?php echo $inf->lema?> </p>
                            <a href="https://es.wikipedia.org/wiki/Steve_Jobs" class="btn btn-dark" target="_blank">View More</a>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
        <br><br>
        <!-- TABLE -->

       

        <div class="table-responsive">
            <table class="table table-hover">
                <thead style="background-color: #D1CDDA;">
                    <tr>
                        <!--<th scope="col">#</th>-->
                        <th scope="col">Product name</th>
                        <th scope="col">Developer</th>
                        <th scope="col">Release year</th>
                        <th scope="col">Price</th>
                        <th scope="col">Category</th>
                    </tr>
                </thead>
                <?php foreach($xmlC->product as $prod) :?>
                <tbody>
                    <tr>
                        <!--<th scope="row">1</th>-->
                        <td><?php echo $prod->name?> </td>
                        <td><?php echo $prod->developer?> </td>
                        <td><?php echo $prod->date?> </td>
                        <td><?php echo $prod->pricing?> </td>
                        <td><?php echo $prod->category?> </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>


<!-- FOOTER -->
        <footer class="page-footer font-small blue pt-4">
            <div class="footer-copyright text-center py-3">© 2020 Copyright:
                <a href="#" target="_blank"> TEAM UCSP</a>
            </div>
        </footer>
    
        <script src="js/jquery-3.5.1.slim.min.js"></script>
        <script src="js/popper.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
    </body>
    
    <!-- SCRIPTS -->
    
    <script type="text/javascript">
        var loader = document.getElementById("loader");
        
        setTimeout(function(){  
        loader.style.height = "100px";
        loader.style.width = "100px";
        loader.style.borderRadius = "50%";
        loader.style.visibility = "hidden";  }, 4000);
        
        $(document).ready(function(){
 
        if(window.innerWidth < 768){
            $('.btn').addClass('btn-sm');
        }
        else if(window.innerWidth < 900){
            $('.btn').removeClass('btn-sm');
        }else if(window.innerWidth < 1200){
            $('.btn').addClass('btn-lg');
        }

        });
    </script>
</html>